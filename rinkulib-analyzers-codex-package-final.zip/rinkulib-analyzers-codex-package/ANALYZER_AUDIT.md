# Analyzer audit

## Scope

The audit covered the analyzer implementation, code fixes, analyzer tests, NuGet packaging, the generated PowerTools schema metadata, and the documentation produced after the first two handoffs.

## Current analyzer surface

The `Rinku` package contains both analyzer assemblies under `analyzers/dotnet/cs`.

The user does not install a separate analyzer package.

The current rules are

```text
RK0000  Hidden   actions for an existing BasedOn link
RK0001  Hidden   add a schema link
RK0002  Hidden   complete a method invocation
RK0100  Warning  stale BasedOn acknowledgement
RK0101  Warning  missing matching constructor
```

The current code fix providers are

```text
AddBasedOnCodeFixProvider
BasedOnLastModifiedCodeFixProvider
GenerateCtorCodeFixProvider
MethodInvocationCodeFixProvider
```

## Documentation regression found

The post handoff source tree had no `docs/articles/codegen/analyzers.md` and no analyzer entry in `docs/articles/codegen/toc.yml`.

The built `_site/articles/codegen/analyzers.html` still existed only as stale output from an older build.

A clean documentation build would therefore remove the analyzer page.

The first handoff caused the navigation regression by replacing the CodeGen TOC without the analyzer entry. The second handoff inherited the omission.

## Old page gaps

The previous analyzer page was not complete enough to restore unchanged.

It did not properly document

```text
Add schema link and its BasedOn or MatchConstructor choices
BasedOn constructor generation actions
constructor plus properties generation
multiple BasedOn links
multiple MatchConstructor links
implicit parameterless constructor matching
source method schemas
same project schema picker scope
manual MatchConstructor references that do not require Schema
missing BasedOn timestamps raising RK0100
method invocation reuse from fields properties and object members
case insensitive invocation argument name matching
threading missing ref out in and params values through the caller
how hidden diagnostics differ from the visible warnings
that analyzers and code fixes ship directly with Rinku
that PowerTools is not required for analyzer use
```

## BasedOn behavior

`BasedOnAnalyzer` emits hidden `RK0000` on each resolvable `BasedOn` reference.

When the referenced declaration has a schema timestamp, `RK0000` carries that timestamp for the code fixes.

`SyncBasedOnAnalyzer` emits `RK0100` when the referenced schema timestamp is newer than the acknowledgement or when the acknowledgement is missing.

`Acknowledge current schema` is supplied from `RK0000`, not directly from `RK0100`.

The same hidden rule also lets `GenerateCtorCodeFixProvider` offer constructor generation from an existing `BasedOn` reference.

`BasedOn` does not itself require a constructor match.

## Add schema link behavior

`AddBasedOnAnalyzer` emits hidden `RK0001` on normal source types only when the compilation contains at least one source declaration carrying `<Schema>`.

It does not offer the action on a type that already has `Schema`, `BasedOn`, or `MatchConstructor` documentation metadata.

The code fix searches source declarations in the current project compilation and includes both types and methods marked with `<Schema>`.

It offers

```text
Track schema changes
Require a matching constructor
```

The first adds `BasedOn` and the current schema timestamp when one exists.

The second adds `MatchConstructor` without a timestamp.

## MatchConstructor behavior

A `MatchConstructor` reference may resolve to a type or a method.

For a type, any one instance constructor may satisfy the link, including an implicit parameterless constructor.

For a method, that method parameter list is the contract.

The match requires

```text
same parameter count
same parameter order
same parameter names with ordinal case sensitive comparison
same parameter types including nullable reference annotations
same ref kind
same params state
```

Parameter attributes and default values do not affect matching.

Multiple `MatchConstructor` references are checked independently.

The constructor code fix copies names, types, nullable annotations, `ref`, `out`, `in`, `params`, and parameter attributes.

Default values are not copied.

The constructor plus properties action is suppressed when an `out` parameter exists or when a generated property name already exists on the target type.

A constructor fix is also suppressed when the target already contains the same legal C# signature even when parameter names differ. This prevents an invalid duplicate constructor.

## Method invocation behavior

`MethodInvocationCompletionAnalyzer` emits hidden `RK0002` for an ordinary or reduced extension method reference inside a method, constructor, or local function when the expression is not already invoked.

It ignores `nameof` and delegate conversions.

The code fix can keep the original member access and supplies every method argument.

For each parameter it tries to reuse

```text
an in scope local parameter field or property with the same name and type
then a matching caller field or property
then a matching public instance field or property on an in scope value
```

Name matching for this feature is ordinal case insensitive.

Type matching uses the Roslyn symbol type comparison used by the implementation.

Missing values are appended to the caller parameter list and passed through.

`ref`, `out`, `in`, and `params` are preserved for added caller parameters and invocation arguments.

When several method candidates are available, the code fix builds a choice for each candidate.

## Schema metadata scope

The analyzer metadata is implemented as XML documentation tags.

PowerTools generated result records carry `<Schema LastUpdated="..." />`.

The add schema link picker discovers source `Schema` declarations in the current project compilation.

Stale `BasedOn` checking also needs source schema metadata because schema timestamps are read from declaring syntax.

A manual `MatchConstructor` can reference another resolvable type or method without a `Schema` tag because its contract comes from Roslyn symbols rather than the schema timestamp metadata.

## PowerTools timestamp behavior

PowerTools creates one generation timestamp and writes it only when a result record is new or its inspected columns changed.

When the result record has not changed, the previous record text is preserved. Its schema timestamp therefore remains unchanged.

This behavior is correct for `BasedOn` because a no shape change refresh should not invalidate reviewed application types.

The generator currently formats the UTC time without an explicit `Z` while analyzer code fixes format acknowledged times with `Z`.

This handoff changes only future generated schema timestamps to

```text
yyyy-MM-ddTHH:mmZ
```

Existing generated timestamps remain valid and are not force rewritten.

## Documentation structure chosen

The analyzer documentation remains under the CodeGen section because generated schemas are the main entry point, but the page explicitly states that the analyzers ship with `Rinku` and do not require PowerTools.

The main documentation index links to the analyzer page independently so method invocation completion and manually authored contracts are discoverable without entering the PowerTools workflow first.

## No analyzer production redesign

The audit did not find a reason to redesign the analyzer contracts for this documentation pass.

The prepared production change is limited to PowerTools timestamp formatting.

The added tests protect schema link suggestion, hidden BasedOn actions, missing and stale acknowledgement warnings, current acknowledgement behavior, independent multiple links, both Add schema link branches, source type and method discovery, BasedOn timestamp insertion, and timestamp free MatchConstructor insertion.
