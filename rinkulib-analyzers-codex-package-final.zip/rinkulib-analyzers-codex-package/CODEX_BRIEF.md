# Codex brief

Apply this package after the first two handoffs.

The product decisions are already made. Do not redesign the analyzer system.

## Apply documentation

Copy each file under `replacement` to the same repository relative path.

Do not delete or replace the surrounding directories.

The documentation changes are

```text
add docs/articles/codegen/analyzers.md
update docs/articles/codegen/toc.yml
update docs/articles/codegen/index.md
update docs/articles/codegen/generated-code.md
update docs/articles/index.md
update docs/articles/overview.md
update README.md
update readmeNuGet.md
```

## Add analyzer tests

Copy

```text
tests-overlay/RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaAnalyzerTests.cs
tests-overlay/RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaCodeFixTests.cs
```

to

```text
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaAnalyzerTests.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaCodeFixTests.cs
```

Do not replace the existing analyzer tests.

## Normalize future generated schema timestamps

Apply `patches/MainClassGenerator-schema-timestamp.patch`.

The intended source change is exactly

```csharp
var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm'Z'");
```

Do not rewrite existing generated result records only to add `Z`.

The existing parser accepts the previous timestamp form. Unchanged result records must continue to preserve their old timestamp.

## Preserve analyzer behavior

The docs are written against the current behavior.

Do not change these contracts during the handoff

```text
RK0000 hidden BasedOn actions
RK0001 hidden add schema link
RK0002 hidden method invocation generation
RK0100 stale BasedOn warning
RK0101 matching constructor warning
```

Do not move the analyzers into RinkuPowerTools. They ship with the `Rinku` package.

## Documentation style

Keep the supplied page content unless a build or source drift requires a concrete correction.

The examples are intentionally user shaped rather than analyzer test shaped.

Do not add `using RinkuLib.Analyzers` examples. The analyzer features are XML documentation tags and Quick Actions, not runtime APIs that application code imports.

Do not describe hidden diagnostics as warnings.

Do not claim that `RK0100` itself owns the acknowledgement code fix. `RK0000` supplies the action on the same `BasedOn` link.

Do not claim that `BasedOn` requires constructor equality. That is `MatchConstructor`.

Do not claim that PowerTools is required to use the analyzers.

## Validation

Run every item in `VALIDATION.md`.

If a prepared analyzer test fails because the implementation has changed, report the exact difference instead of weakening the test or documentation to make the run green.
