# Start here

This is the third sequential handoff.

Apply it only after the previous RinkuPowerTools and multi database handoffs have been applied successfully.

This handoff rebuilds the analyzer documentation from the analyzer source and tests. It also adds missing analyzer test coverage and one timestamp formatting correction in PowerTools.

Do not redesign the analyzer APIs or documentation structure during application.

## Order

1. Read `ANALYZER_AUDIT.md`
2. Read `SOURCE_AUDIT.md`
3. Apply the files in `replacement`
4. Add the files in `tests-overlay`
5. Apply the patch in `patches`
6. Run the validation in `VALIDATION.md`
7. Report any source drift or failing test instead of replacing the prepared behavior with another design

## Preservation rule

Do not replace an entire documentation directory from this package.

Only the files listed in `MANIFEST.md` are intentional documentation changes. Preserve every unrelated source page and navigation entry.
