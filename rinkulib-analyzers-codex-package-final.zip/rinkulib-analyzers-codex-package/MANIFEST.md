# Manifest

## Documentation replacement files

```text
replacement/docs/articles/index.md
replacement/docs/articles/overview.md
replacement/docs/articles/codegen/analyzers.md
replacement/docs/articles/codegen/generated-code.md
replacement/docs/articles/codegen/index.md
replacement/docs/articles/codegen/toc.yml
replacement/README.md
replacement/readmeNuGet.md
```

## Test overlay

```text
tests-overlay/RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaAnalyzerTests.cs
tests-overlay/RinkuLib.Analyzers/RinkuLib.Analyzers.Test/SchemaCodeFixTests.cs
```

## Production patch

```text
patches/MainClassGenerator-schema-timestamp.patch
```

## Handoff documents

```text
START_HERE.md
ANALYZER_AUDIT.md
SOURCE_AUDIT.md
CODEX_BRIEF.md
VALIDATION.md
MANIFEST.md
CHECKSUMS.md
```
