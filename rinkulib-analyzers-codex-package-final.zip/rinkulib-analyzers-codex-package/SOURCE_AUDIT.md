# Source audit

The prepared documentation was checked against these current source areas.

```text
RinkuLib.Analyzers/RinkuLib.Analyzers/AddBasedOnAnalyzer.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/BasedOnAnalyzer.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/ConstructorContract.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/DocumentationTags.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/MatchConstructorAnalyzer.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/MethodInvocationCompletionAnalyzer.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/SyncBasedOnAnalyzer.cs
RinkuLib.Analyzers/RinkuLib.Analyzers/AnalyzerReleases.Unshipped.md
RinkuLib.Analyzers/RinkuLib.Analyzers.CodeFixes/AddBasedOnCodeFixProvider.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.CodeFixes/BasedOnLastModifiedCodeFixProvider.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.CodeFixes/GenerateCtorCodeFixProvider.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.CodeFixes/MethodInvocationCodeFixProvider.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/AnalyzerInfrastructureTests.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/GenerationCodeFixTests.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/MatchConstructorAnalyzerTests.cs
RinkuLib.Analyzers/RinkuLib.Analyzers.Test/MethodInvocationAnalyzerTests.cs
RinkuLib/RinkuLib.csproj
README.md
readmeNuGet.md
RinkuPowerTools/RinkuPowerTools/MainClassGenerator.cs
```

The supplied post handoff documentation ZIP was also inspected as the documentation baseline.

The repository `README.md` and `readmeNuGet.md` replacements are based on the versions prepared by the first handoff, not on the older public-main wording. This prevents the analyzer handoff from reverting the README rewrite that should already be present when this third handoff runs.

## Expected source state before applying

The two earlier handoffs should already be applied.

Before copying anything, verify

```text
docs/articles/codegen/analyzers.md is absent or is the old incomplete page
RinkuPowerTools supports SQL Server PostgreSQL and SQLite from the second handoff
RinkuPowerTools/RinkuPowerTools/MainClassGenerator.cs still creates schema timestamps with DateTime.UtcNow
RinkuLib.Analyzers contains RK0000 RK0001 RK0002 RK0100 RK0101
```

If the analyzer rule IDs or code fix behavior have changed, stop and report the source drift before applying the prepared docs.

## Files that must not be removed

This package is not a directory replacement.

Do not remove any existing CodeGen page or any other documentation page.

The only new source documentation page is

```text
docs/articles/codegen/analyzers.md
```

The other documentation files in `replacement` are targeted edits of existing pages.
