# Validation

## Source preservation

Before and after applying the package, inventory source documentation pages.

No unrelated `.md` or `toc.yml` file may disappear.

Confirm that these CodeGen source pages all exist afterward

```text
docs/articles/codegen/index.md
docs/articles/codegen/configure.md
docs/articles/codegen/queries.md
docs/articles/codegen/generated-code.md
docs/articles/codegen/analyzers.md
docs/articles/codegen/refresh.md
docs/articles/codegen/configuration.md
docs/articles/codegen/toc.yml
```

## Analyzer tests

Run the analyzer test project.

```text
dotnet test RinkuLib.Analyzers/RinkuLib.Analyzers.Test/RinkuLib.Analyzers.Test.csproj
```

The new `SchemaAnalyzerTests` and `SchemaCodeFixTests` must pass together with all existing analyzer and code fix tests.

## Rinku build and tests

Build the solution or the same repository targets used by the previous handoffs.

At minimum build the analyzer projects, the Rinku package project, and RinkuPowerTools.

Run the existing Rinku and PowerTools tests used by the previous handoffs.

## Package verification

Pack `Rinku` and inspect the package.

Confirm both files are still present under `analyzers/dotnet/cs`.

```text
RinkuLib.Analyzers.dll
RinkuLib.Analyzers.CodeFixes.dll
```

No separate analyzer package should be required.

## Generated timestamp behavior

Regenerate a query whose result record has not changed.

Its existing record and `Schema LastUpdated` value must remain unchanged.

Change the inspected result shape and refresh again.

The rewritten record must use an explicit UTC timestamp ending in `Z`.

```csharp
/// <Schema LastUpdated="2026-08-21T20:49Z" />
```

The exact minute will differ.

## Analyzer workflow smoke test

In a normal C# project referencing `Rinku`, create a source schema and an unlinked application type.

```csharp
/// <Schema LastUpdated="2026-08-21T20:49Z" />
public record AlbumSchema(int Id, string Title);

public record AlbumDto(int Id, string Title);
```

Confirm `AlbumDto` offers `Add schema link` with both choices.

```text
Track schema changes
Require a matching constructor
```

Choose `Track schema changes` and confirm it adds `BasedOn` with the current timestamp.

Make the schema timestamp newer and confirm `RK0100` appears.

Confirm `Acknowledge current schema` updates only the acknowledgement timestamp.

Add a mismatching `MatchConstructor` link and confirm `RK0101` appears with constructor generation actions when a legal constructor can be added.

Use an uninvoked method reference and confirm `Generate invocation` reuses matching values or adds missing caller parameters.

## Documentation build

Delete or clean stale DocFX output before building so an old `_site/articles/codegen/analyzers.html` cannot hide a missing source page.

Build DocFX.

Confirm the new page exists in the clean output and appears in CodeGen navigation.

Confirm these links resolve

```text
articles/index.md to codegen/analyzers.md
articles/overview.md to codegen/analyzers.md
articles/codegen/index.md to analyzers.md
articles/codegen/generated-code.md to analyzers.md
```

Confirm the documentation build has no new warnings or broken links.
